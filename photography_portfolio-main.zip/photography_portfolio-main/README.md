# test_portfolio
Frontend design of a photography portfolio with dynamic variations using HTML,CSS and JAVASCRIPT 
![image 1](https://github.com/mlsoumika05/photography_portfolio/assets/134679466/a38ddf64-b9fd-426d-9c5e-2672167211fb)
![image 2](https://github.com/mlsoumika05/photography_portfolio/assets/134679466/c2db75f1-d5a9-4284-a5a1-24e224da7f68)
